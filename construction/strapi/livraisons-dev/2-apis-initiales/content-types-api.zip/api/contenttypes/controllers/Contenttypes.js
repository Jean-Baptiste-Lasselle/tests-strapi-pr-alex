'use strict';

/**
 * Contenttypes.js controller
 *
 * @description: A set of functions called "actions" for managing `Contenttypes`.
 */

module.exports = {

  /**
   * Retrieve contenttypes records.
   *
   * @return {Object|Array}
   */

  find: async (ctx) => {
    return strapi.services.contenttypes.fetchAll(ctx.query);
  },

  /**
   * Retrieve a contenttypes record.
   *
   * @return {Object}
   */

  findOne: async (ctx) => {
    if (!ctx.params._id.match(/^[0-9a-fA-F]{24}$/)) {
      return ctx.notFound();
    }

    return strapi.services.contenttypes.fetch(ctx.params);
  },

  /**
   * Create a/an contenttypes record.
   *
   * @return {Object}
   */

  create: async (ctx) => {
    return strapi.services.contenttypes.add(ctx.request.body);
  },

  /**
   * Update a/an contenttypes record.
   *
   * @return {Object}
   */

  update: async (ctx, next) => {
    return strapi.services.contenttypes.edit(ctx.params, ctx.request.body) ;
  },

  /**
   * Destroy a/an contenttypes record.
   *
   * @return {Object}
   */

  destroy: async (ctx, next) => {
    return strapi.services.contenttypes.remove(ctx.params);
  }
};
