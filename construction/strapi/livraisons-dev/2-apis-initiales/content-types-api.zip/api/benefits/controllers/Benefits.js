'use strict';

/**
 * Benefits.js controller
 *
 * @description: A set of functions called "actions" for managing `Benefits`.
 */

module.exports = {

  /**
   * Retrieve benefits records.
   *
   * @return {Object|Array}
   */

  find: async (ctx) => {
    return strapi.services.benefits.fetchAll(ctx.query);
  },

  /**
   * Retrieve a benefits record.
   *
   * @return {Object}
   */

  findOne: async (ctx) => {
    if (!ctx.params._id.match(/^[0-9a-fA-F]{24}$/)) {
      return ctx.notFound();
    }

    return strapi.services.benefits.fetch(ctx.params);
  },

  /**
   * Create a/an benefits record.
   *
   * @return {Object}
   */

  create: async (ctx) => {
    return strapi.services.benefits.add(ctx.request.body);
  },

  /**
   * Update a/an benefits record.
   *
   * @return {Object}
   */

  update: async (ctx, next) => {
    return strapi.services.benefits.edit(ctx.params, ctx.request.body) ;
  },

  /**
   * Destroy a/an benefits record.
   *
   * @return {Object}
   */

  destroy: async (ctx, next) => {
    return strapi.services.benefits.remove(ctx.params);
  }
};
