'use strict';

/**
 * Composants.js controller
 *
 * @description: A set of functions called "actions" for managing `Composants`.
 */

module.exports = {

  /**
   * Retrieve composants records.
   *
   * @return {Object|Array}
   */

  find: async (ctx) => {
    return strapi.services.composants.fetchAll(ctx.query);
  },

  /**
   * Retrieve a composants record.
   *
   * @return {Object}
   */

  findOne: async (ctx) => {
    if (!ctx.params._id.match(/^[0-9a-fA-F]{24}$/)) {
      return ctx.notFound();
    }

    return strapi.services.composants.fetch(ctx.params);
  },

  /**
   * Create a/an composants record.
   *
   * @return {Object}
   */

  create: async (ctx) => {
    return strapi.services.composants.add(ctx.request.body);
  },

  /**
   * Update a/an composants record.
   *
   * @return {Object}
   */

  update: async (ctx, next) => {
    return strapi.services.composants.edit(ctx.params, ctx.request.body) ;
  },

  /**
   * Destroy a/an composants record.
   *
   * @return {Object}
   */

  destroy: async (ctx, next) => {
    return strapi.services.composants.remove(ctx.params);
  }
};
