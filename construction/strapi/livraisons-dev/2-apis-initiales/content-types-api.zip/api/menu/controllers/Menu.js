'use strict';

/**
 * Menu.js controller
 *
 * @description: A set of functions called "actions" for managing `Menu`.
 */

module.exports = {

  /**
   * Retrieve menu records.
   *
   * @return {Object|Array}
   */

  find: async (ctx) => {
    return strapi.services.menu.fetchAll(ctx.query);
  },

  /**
   * Retrieve a menu record.
   *
   * @return {Object}
   */

  findOne: async (ctx) => {
    if (!ctx.params._id.match(/^[0-9a-fA-F]{24}$/)) {
      return ctx.notFound();
    }

    return strapi.services.menu.fetch(ctx.params);
  },

  /**
   * Create a/an menu record.
   *
   * @return {Object}
   */

  create: async (ctx) => {
    return strapi.services.menu.add(ctx.request.body);
  },

  /**
   * Update a/an menu record.
   *
   * @return {Object}
   */

  update: async (ctx, next) => {
    return strapi.services.menu.edit(ctx.params, ctx.request.body) ;
  },

  /**
   * Destroy a/an menu record.
   *
   * @return {Object}
   */

  destroy: async (ctx, next) => {
    return strapi.services.menu.remove(ctx.params);
  }
};
