'use strict';

/**
 * Langues.js controller
 *
 * @description: A set of functions called "actions" for managing `Langues`.
 */

module.exports = {

  /**
   * Retrieve langues records.
   *
   * @return {Object|Array}
   */

  find: async (ctx) => {
    if (ctx.query._q) {
      return strapi.services.langues.search(ctx.query);
    } else {
      return strapi.services.langues.fetchAll(ctx.query);
    }
  },

  /**
   * Retrieve a langues record.
   *
   * @return {Object}
   */

  findOne: async (ctx) => {
    if (!ctx.params._id.match(/^[0-9a-fA-F]{24}$/)) {
      return ctx.notFound();
    }

    return strapi.services.langues.fetch(ctx.params);
  },

  /**
   * Count langues records.
   *
   * @return {Number}
   */

  count: async (ctx) => {
    return strapi.services.langues.count(ctx.query);
  },

  /**
   * Create a/an langues record.
   *
   * @return {Object}
   */

  create: async (ctx) => {
    return strapi.services.langues.add(ctx.request.body);
  },

  /**
   * Update a/an langues record.
   *
   * @return {Object}
   */

  update: async (ctx, next) => {
    return strapi.services.langues.edit(ctx.params, ctx.request.body) ;
  },

  /**
   * Destroy a/an langues record.
   *
   * @return {Object}
   */

  destroy: async (ctx, next) => {
    return strapi.services.langues.remove(ctx.params);
  }
};
