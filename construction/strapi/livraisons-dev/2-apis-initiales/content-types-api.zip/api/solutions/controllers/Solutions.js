'use strict';

/**
 * Solutions.js controller
 *
 * @description: A set of functions called "actions" for managing `Solutions`.
 */

module.exports = {

  /**
   * Retrieve solutions records.
   *
   * @return {Object|Array}
   */

  find: async (ctx) => {
    return strapi.services.solutions.fetchAll(ctx.query);
  },

  /**
   * Retrieve a solutions record.
   *
   * @return {Object}
   */

  findOne: async (ctx) => {
    if (!ctx.params._id.match(/^[0-9a-fA-F]{24}$/)) {
      return ctx.notFound();
    }

    return strapi.services.solutions.fetch(ctx.params);
  },

  /**
   * Create a/an solutions record.
   *
   * @return {Object}
   */

  create: async (ctx) => {
    console.log('I have created a new input field');
    return strapi.services.solutions.add(ctx.request.body);
  },

  /**
   * Update a/an solutions record.
   *
   * @return {Object}
   */

  update: async (ctx, next) => {
    return strapi.services.solutions.edit(ctx.params, ctx.request.body) ;
  },

  /**
   * Destroy a/an solutions record.
   *
   * @return {Object}
   */

  destroy: async (ctx, next) => {
    return strapi.services.solutions.remove(ctx.params);
  }

  

};
