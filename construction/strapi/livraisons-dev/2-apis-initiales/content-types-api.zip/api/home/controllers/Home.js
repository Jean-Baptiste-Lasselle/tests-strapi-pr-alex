'use strict';

/**
 * Home.js controller
 *
 * @description: A set of functions called "actions" for managing `Home`.
 */

module.exports = {

  /**
   * Retrieve home records.
   *
   * @return {Object|Array}
   */

  find: async (ctx) => {
    return strapi.services.home.fetchAll(ctx.query);
  },

  /**
   * Retrieve a home record.
   *
   * @return {Object}
   */

  findOne: async (ctx) => {
    if (!ctx.params._id.match(/^[0-9a-fA-F]{24}$/)) {
      return ctx.notFound();
    }

    return strapi.services.home.fetch(ctx.params);
  },

  /**
   * Create a/an home record.
   *
   * @return {Object}
   */

  create: async (ctx) => {
    return strapi.services.home.add(ctx.request.body);
  },

  /**
   * Update a/an home record.
   *
   * @return {Object}
   */

  update: async (ctx, next) => {
    return strapi.services.home.edit(ctx.params, ctx.request.body) ;
  },

  /**
   * Destroy a/an home record.
   *
   * @return {Object}
   */

  destroy: async (ctx, next) => {
    return strapi.services.home.remove(ctx.params);
  }
};
